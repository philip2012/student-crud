<!-- App.vue -->
<script setup>
import { ref, computed } from "vue";
import AddStudent from "./Components/AddStudent.vue";
import RecordTable from "./Components/RecordTable.vue";
import StudentStatistics from "./Components/StudentStatistics.vue";

const students = ref([]);
const editingStudent = ref(null);

const nextId = () =>
  students.value.length ? Math.max(...students.value.map((s) => s.id)) + 1 : 1;

const addStudent = (data) => {
  students.value = [...students.value, { id: nextId(), ...data }];
};

const startEdit = (student) => {
  editingStudent.value = { ...student };
};

const updateStudent = (updated) => {
  students.value = students.value.map((s) =>
    s.id === updated.id ? { ...updated } : s
  );
  editingStudent.value = null;
};

const deleteStudent = (id) => {
  students.value = students.value.filter((s) => s.id !== id);
  if (editingStudent.value?.id === id) editingStudent.value = null;
};

const studentCount = computed(() => students.value.length);

const globalAverage = computed(() => {
  if (!students.value.length) return "0.0";
  const total = students.value.reduce(
    (sum, s) => sum + (s.math + s.science + s.english) / 3,
    0
  );
  return (total / students.value.length).toFixed(1);
});
</script>

<template>
  <main class="min-h-screen bg-gray-50">
    <div class="mx-auto max-w-6xl px-6 pt-10 flex flex-col gap-6">
      <h1 class="text-3xl font-semibold text-center">
        Student Management System (CRUD)
      </h1>

      <p class="text-gray-500 text-center">
        Manage each student with CRUD operations with ease
      </p>

      <!-- Two-panel layout -->
      <div class="w-full grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        <AddStudent />
        <StudentStatistics />
      </div>

      <RecordTable />
    </div>
  </main>
</template>

<style scoped></style>
