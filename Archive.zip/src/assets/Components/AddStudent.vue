<template>
  <section
    class="w-full rounded-3xl bg-white shadow-xl ring-1 ring-black/5 p-8"
  >
    <h2 class="text-3xl font-semibold text-slate-900">Add New Student</h2>

    <div class="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
      <div class="flex flex-col gap-2">
        <label class="text-slate-700 font-medium" for="firstName"
          >First Name *</label
        >
        <input
          id="firstName"
          type="text"
          placeholder="Enter first name"
          class="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-slate-900 placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-blue-500/30"
        />
      </div>

      <div class="flex flex-col gap-2">
        <label class="text-slate-700 font-medium" for="lastName"
          >Last Name *</label
        >
        <input
          id="lastName"
          type="text"
          placeholder="Enter last name"
          class="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-slate-900 placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-blue-500/30"
        />
      </div>
    </div>

    <h3 class="mt-8 text-xl font-semibold text-slate-900">Scores (0-100)</h3>

    <div class="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-6">
      <div class="flex flex-col gap-2">
        <label class="text-slate-700 font-medium" for="mathScore">Math</label>
        <input
          id="mathScore"
          type="number"
          value="0"
          class="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-slate-900 outline-none focus:ring-2 focus:ring-blue-500/30"
        />
      </div>

      <div class="flex flex-col gap-2">
        <label class="text-slate-700 font-medium" for="scienceScore"
          >Science</label
        >
        <input
          id="scienceScore"
          type="number"
          value="0"
          class="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-slate-900 outline-none focus:ring-2 focus:ring-blue-500/30"
        />
      </div>

      <div class="flex flex-col gap-2">
        <label class="text-slate-700 font-medium" for="englishScore"
          >English</label
        >
        <input
          id="englishScore"
          type="number"
          value="0"
          class="h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-slate-900 outline-none focus:ring-2 focus:ring-blue-500/30"
        />
      </div>
    </div>

    <div class="mt-8 rounded-2xl bg-slate-50 p-6">
      <div class="flex items-center justify-between">
        <h4 class="text-lg font-semibold text-slate-900">
          Performance Summary
        </h4>
        <p class="text-slate-500">Average: 0.0</p>
      </div>

      <div class="mt-4 flex items-center justify-between">
        <p class="text-slate-600">Total Score:</p>
        <p class="text-lg font-semibold text-slate-900">0/300</p>
      </div>

      <div
        class="mt-4 h-3 w-full rounded-full bg-slate-200 overflow-hidden"
      ></div>

      <div class="mt-4 flex items-center justify-between text-slate-400">
        <p>0</p>
        <p>50</p>
        <p>100</p>
      </div>
    </div>

    <button
      class="mt-8 h-14 w-full rounded-xl bg-blue-600 text-white text-lg font-semibold shadow-sm hover:bg-blue-700 active:bg-blue-800"
    >
      Add Student
    </button>
  </section>
</template>

<!-- AddStudent.vue -->
<script setup>
// --- imports --- //
import { ref, watch, computed } from "vue";

// --- props / emits --- //
const props = defineProps({
  student: Object,
});

const emit = defineEmits(["add-student", "update-student", "cancel-edit"]);

// --- form state --- //
const form = ref({
  id: null,
  name: "",
  math: 0,
  science: 0,
  english: 0,
});

const isEditing = computed(() => !!props.student);

// --- sync edit --- //
watch(
  () => props.student,
  (s) => {
    form.value = s
      ? { ...s }
      : { id: null, name: "", math: 0, science: 0, english: 0 };
  },
  { immediate: true }
);

// --- helpers --- //
const clamp = (k) => {
  form.value[k] = Math.min(100, Math.max(0, Number(form.value[k]) || 0));
};

const average = computed(() =>
  ((+form.value.math + +form.value.science + +form.value.english) / 3).toFixed(
    1
  )
);

const submit = () => {
  if (!form.value.name.trim()) return;

  const payload = {
    id: form.value.id,
    name: form.value.name.trim(),
    math: +form.value.math,
    science: +form.value.science,
    english: +form.value.english,
  };

  isEditing.value
    ? emit("update-student", payload)
    : emit("add-student", payload);

  if (!isEditing.value) {
    form.value = { id: null, name: "", math: 0, science: 0, english: 0 };
  }
};
</script>
