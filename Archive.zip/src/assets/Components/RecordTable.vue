<!-- RecordTable.vue -->
<template>
  <section
    class="w-full rounded-3xl bg-white shadow-xl ring-1 ring-black/5 overflow-hidden"
  >
    <!-- Header -->
    <div class="px-8 py-6 flex items-start justify-between">
      <div>
        <h2 class="text-3xl font-semibold text-slate-900">Student Records</h2>
        <p class="mt-1 text-slate-500">3 students found</p>
      </div>

      <p class="text-slate-500">Showing all students</p>
    </div>

    <div class="h-px bg-slate-200"></div>

    <!-- Table -->
    <div class="w-full overflow-x-auto">
      <table class="w-full min-w-275">
        <thead class="bg-slate-50">
          <tr
            class="text-left text-xs font-semibold tracking-widest text-slate-500 uppercase"
          >
            <th class="px-8 py-4 w-55">ID</th>
            <th class="px-8 py-4 w-[320px]">Student Info</th>
            <th class="px-8 py-4 w-40">Math</th>
            <th class="px-8 py-4 w-40">Physics</th>
            <th class="px-8 py-4 w-40">English</th>
            <th class="px-8 py-4 w-55">Average Score</th>
            <th class="px-8 py-4 w-40">Ranking</th>
            <th class="px-8 py-4 w-55">Actions</th>
          </tr>
        </thead>

        <tbody class="divide-y divide-slate-200">
          <tr class="align-middle">
            <!-- ID bubble -->
            <td class="px-8 py-6">
              <div class="flex items-center gap-4">
                <div
                  class="h-16 w-16 rounded-full bg-blue-50 flex items-center justify-center font-semibold text-blue-700"
                >
                  #002
                </div>
              </div>
            </td>

            <!-- Student info -->
            <td class="px-8 py-6">
              <p class="text-2xl font-semibold text-slate-900 leading-tight">
                A B
              </p>
              <p class="mt-2 text-slate-500">Student ID: STU0002</p>
            </td>

            <!-- Score cell helper -->
            <td class="px-8 py-6">
              <p class="text-2xl font-semibold text-slate-900">50</p>
              <div
                class="mt-3 h-3 w-28 rounded-full bg-slate-200 overflow-hidden"
              >
                <div class="h-full w-1/2 rounded-full bg-orange-500"></div>
              </div>
            </td>

            <td class="px-8 py-6">
              <p class="text-2xl font-semibold text-slate-900">40</p>
              <div
                class="mt-3 h-3 w-28 rounded-full bg-slate-200 overflow-hidden"
              >
                <div class="h-full w-[40%] rounded-full bg-orange-500"></div>
              </div>
            </td>

            <td class="px-8 py-6">
              <p class="text-2xl font-semibold text-slate-900">100</p>
              <div
                class="mt-3 h-3 w-28 rounded-full bg-slate-200 overflow-hidden"
              >
                <div class="h-full w-full rounded-full bg-emerald-500"></div>
              </div>
            </td>

            <!-- Average -->
            <td class="px-8 py-6">
              <p class="text-4xl font-semibold text-slate-900">63.3</p>
              <div
                class="mt-3 h-3 w-36 rounded-full bg-slate-200 overflow-hidden"
              >
                <div class="h-full w-[63.3%] rounded-full bg-amber-500"></div>
              </div>
            </td>

            <!-- Ranking pill -->
            <td class="px-8 py-6">
              <span
                class="inline-flex items-center justify-center px-10 py-3 rounded-full bg-orange-500 text-white font-semibold"
              >
                D
              </span>
            </td>

            <!-- Actions -->
            <td class="px-8 py-6">
              <div class="flex items-center gap-4">
                <button
                  class="px-8 py-4 rounded-2xl bg-blue-600 text-white text-lg font-semibold shadow-lg shadow-blue-200 hover:bg-blue-700"
                >
                  Edit
                </button>
                <button
                  class="px-8 py-4 rounded-2xl bg-red-600 text-white text-lg font-semibold shadow-lg shadow-red-200 hover:bg-red-700"
                >
                  Delete
                </button>
              </div>
            </td>
          </tr>

          <!-- Copy thêm rows y chang ở đây -->
        </tbody>
      </table>
    </div>

    <!-- Footer summary -->
    <div class="h-px bg-slate-200"></div>
    <div class="px-8 py-5 flex items-center justify-between text-slate-600">
      <p>
        <span class="font-semibold text-slate-700">Summary:</span>
        Highest Average: 80.0, Lowest Average: 63.3
      </p>

      <p class="flex items-center gap-3">
        <span class="font-semibold text-slate-700"
          >Overall Class Performance:</span
        >
        <span
          class="px-4 py-2 rounded-full bg-blue-50 text-blue-700 font-semibold"
          >Good</span
        >
      </p>
    </div>
  </section>
</template>

<!-- RecordTable.vue -->
<script setup>
const props = defineProps({
  students: {
    type: Array,
    required: true,
  },
});

const emit = defineEmits(["edit", "delete"]);

const avg = (s) => ((s.math + s.science + s.english) / 3).toFixed(1);
</script>
