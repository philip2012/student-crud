<!-- StatisticsPanel.vue -->
<template>
  <section
    class="w-full rounded-3xl bg-white shadow-xl ring-1 ring-black/5 p-8"
  >
    <h2 class="text-3xl font-semibold text-slate-900 mb-6">Statistics</h2>

    <!-- Top: Total Students -->
    <div class="rounded-2xl border border-slate-200 bg-sky-50/70 p-6">
      <p class="text-slate-600 font-medium">Total Students</p>
      <p class="mt-2 text-5xl font-bold text-blue-600 leading-none">
        {{ stats.totalStudents }}
      </p>
    </div>

    <!-- Middle: 3 cards -->
    <div class="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-6">
      <div class="rounded-2xl border border-slate-200 bg-emerald-50/70 p-6">
        <p class="text-slate-600 font-medium">Avg Math</p>
        <p class="mt-3 text-4xl font-bold text-emerald-600 leading-none">
          {{ stats.avgMath.toFixed(1) }}
        </p>
      </div>

      <div class="rounded-2xl border border-slate-200 bg-sky-50/70 p-6">
        <p class="text-slate-600 font-medium">Avg Science</p>
        <p class="mt-3 text-4xl font-bold text-sky-600 leading-none">
          {{ stats.avgScience.toFixed(1) }}
        </p>
      </div>

      <div class="rounded-2xl border border-slate-200 bg-violet-50/70 p-6">
        <p class="text-slate-600 font-medium">Avg English</p>
        <p class="mt-3 text-4xl font-bold text-violet-600 leading-none">
          {{ stats.avgEnglish.toFixed(1) }}
        </p>
      </div>
    </div>

    <!-- Bottom: Average Overall Score -->
    <div class="mt-6 rounded-2xl border border-amber-200/70 bg-amber-50/70 p-6">
      <p class="text-slate-700 font-medium">Average Overall Score</p>

      <div class="mt-3 flex items-end gap-3">
        <p class="text-5xl font-extrabold text-amber-600 leading-none">
          {{ stats.avgOverall.toFixed(1) }}
        </p>
      </div>

      <!-- Progress -->
      <div class="mt-5 h-3 w-full rounded-full bg-slate-200 overflow-hidden">
        <div
          class="h-full rounded-full bg-amber-500"
          :style="{ width: `${overallPercent}%` }"
        ></div>
      </div>
    </div>
  </section>
</template>

<!-- StudentStatistics.vue -->
<script setup>
import { computed } from "vue";

const props = defineProps({
  students: {
    type: Array,
    required: true,
  },
});

const count = computed(() => props.students.length);

const average = computed(() => {
  if (!props.students.length) return "0.0";
  const total = props.students.reduce(
    (sum, s) => sum + (s.math + s.science + s.english) / 3,
    0
  );
  return (total / props.students.length).toFixed(1);
});
</script>

<style scoped></style>
